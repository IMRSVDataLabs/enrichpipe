# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['enrichpipe']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.20.1,<2.0.0',
 'pandas>=1.2.3,<2.0.0',
 'python-semantic-release>=7.15.0,<8.0.0',
 'seaborn>=0.11.1,<0.12.0',
 'sklearn>=0.0,<0.1']

setup_kwargs = {
    'name': 'enrichpipe',
    'version': '0.1.5',
    'description': '',
    'long_description': '# enrichPipe \n\n[![build](https://github.com/lara-imrsv/enrichPipe/actions/workflows/build.yml/badge.svg)](https://github.com/lara-imrsv/enrichPipe/actions/workflows/build.yml)\n[![Deploy](https://github.com/lara-imrsv/enrichPipe/actions/workflows/deploy.yml/badge.svg)](https://github.com/lara-imrsv/enrichPipe/actions/workflows/deploy.yml)\n![](https://github.com/lara-imrsv/enrichPipe/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/lara-imrsv/enrichPipe/branch/main/graph/badge.svg?token=3KW44NKWAS)](https://codecov.io/gh/lara-imrsv/enrichPipe) [![Documentation Status](https://readthedocs.org/projects/enrichPipe/badge/?version=latest)](https://enrichPipe.readthedocs.io/en/latest/?badge=latest)\n\n## Summary\n\nenrichPipe is a python package designed to perform exploratory data analysis, to help with missing data imputation and to give baseline models. Also, it assists\xa0in feature selection which is a common problem when undertaking a data science or machine learning analysis. As its name indicates, this function\xa0operates like sklearn. It carries out tasks such as\xa0splitting\xa0data, feature selection, model fitting, numerical missing data imputation etc.\n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ enrichPipe\n```\n\n## Features\n\nThis package introduces features used to enrich databases with query result curated data. All functions can be used on a dataset with text data. The functions might have their own required and optional arguments.\n\n- alphabet check\n- bleu score\n\n## Dependencies\n\n\n- python = "^3.8"\n- pandas = "^1.2.3"\n- numpy = "^1.20.1"\n- matplotlib = "^3.3.4"\n- sklearn = "^0.0"\n- seaborn = "^0.11.1"\n- ipython = "^7.21.0"    \n- jupyter = "^1.0.0"\n\n\n## Usage\n\n| Task | Function  |\n|------------|-----|\n| Alphabet Check| `alphabet_check(\'Suspected English\', lang=\'en\')`|\n| Compute Bleu Score| `bleu_score(references=[\'hi\'], hypothesis=\'Happy world\',weight=(0.7,0.3))`|\n\n\n## Example\n\n```Python\n\nfrom enrichPipe import alphabet_check, bleu_score\nTODO \n\n```\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://enrichPipe.readthedocs.io/en/latest/\n\n## Contributors\n\nDevelopment Team:\n\n- Lara Habashy\n- Wyatt Kyte\n\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](). If you would like to contribute, please view our [contributing guidelines]() and get familiar with the [Github flow](https://blog.programster.org/git-workflows) workflow.\n\n### Credits\n\nThis package was created with Cookiecutter project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'lara-imrsv',
    'author_email': 'lara@imrsv.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/lara-imrsv/enrichPipe',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
